import { useState } from "react";

const hideMe=(flag)=>{
    if(flag){
        return(<button> Show Hide </button>)
    }
}
function ShowHideApp() {
    const [hide,setHide] = useState(false);
    const toShowHide = () =>{
        setHide(!hide);
    }
  return (
    <div className="App">
        <button onClick={toShowHide} > click to show / hide</button> <br/><br/>
        {hideMe(hide)}

    </div>
  );
}

export default ShowHideApp;
