//function componrnt
import React, { useEffect } from 'react';

export function StudentFunc({name,email}) {
  return (
    <div>
      <h3>StudentF Name {name} </h3>
      <h3>StudentF email {email} </h3>
    </div>
  );
}

export class StudentC extends React.Component {
    state={cpunt:0};
    render(){
        return (
            <div>
              <h3>StudentC Name {this.props.name} </h3>
              <h3>StudentC email {this.props.email} </h3>
            </div>
          );

    }
}
//import {StudentFunc} from './components/Student'; in App
