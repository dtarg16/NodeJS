import { Preview, print } from 'react-html2pdf';
 
function Sample() {
    return (
       <div>
        //render
        <Preview id={'jsx-template'} >
            <p>adsf</p>
        </Preview>
        <button onClick={()=>print('a', 'jsx-template')}> print</button>
       </div>
    );
 }
  export default Sample;
