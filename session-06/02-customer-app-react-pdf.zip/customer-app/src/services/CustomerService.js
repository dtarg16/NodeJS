//services/CustomerService.js
let customers = [ 
	{id:1,name:'Vivek S', email:'vivek@abc.com', phone:'8989389333',address:"Singapore"},
	{id:2,name:'Dev', email:'dev@abc.com', phone:'866u389333',address:"India"},
	{id:3,name:'Ameer', email:'ameer@abc.com', phone:'877779333',address:"Asia"},
	{id:4, name:'Dian', email:'dian@gmail.com', phone:"1234567876", address:'Singapore'},
	{id:5, name:'Apple', email:'dian@gmail.com', phone:"1234567876", address:'Singapore'},
	{id:6, name:'Orange', email:'dian@gmail.com', phone:"1234567876", address:'Singapore'}
	];

export const getCustomers = () => (customers);

const getNextId = () =>{
    if(customers.length < 1){
       return 1; 
    }
    let numberArry = customers.map((item)=>{return item.id});
    let max = Math.max(...numberArry);// (5,6,6) // spread operator
    return max + 1; 
}
export const addCustomer = (record) => {
    //1662542180483
    // id should be number and increment 
    record.id = getNextId();
    customers.push(record);
};

export const updateCustomer = (customer) => {
    let temp = customers.filter((record)=>(customer.id == record.id));
    if(temp.length > 0){
        temp[0].name = customer.name;
        temp[0].email = customer.email;
        temp[0].phone = customer.phone;
        temp[0].address = customer.address;
    };
}
export const deleteCustomer = ({id}) => {
    customers = customers.filter((record)=>(id != record.id));
};

export  const getCustomerById = (id) =>{
    let temp =  customers.filter((record)=>(record.id == id));
    if(temp.length > 0){
        return temp[0];
    }else{
        return {}
    }
}
//CustomerService.js
export const searchCustomer = (fieldName,searchWord) =>{
    console.log("fieldName:"+fieldName);
    console.log("searchWord:"+searchWord);
    let temp =  customers.filter((record)=>(record[fieldName].toLowerCase().startsWith(searchWord.toLowerCase())));
    return temp;
}


