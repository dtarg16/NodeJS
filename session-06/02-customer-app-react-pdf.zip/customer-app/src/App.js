import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './containers/Home';
import Login from './containers/Login';
import About from './containers/About';
import PageNotFound from './containers/PageNotFound';
import { CustomerAppF } from './containers/CustomerApp';
import Customer from './containers/Customer';
import AddCustomer from './containers/AddCustomer';

const App = () => {
   return (
     <Router>
      <div style={{marginLeft:'10px'}}>
         <Routes>
           <Route exact path="/" element={<Home/>}/>
           <Route exact path="/customer" element={<Customer/>}/>
           <Route exact path="/customer/add" element={<AddCustomer/>}/>
           <Route exact path="/customers/edit/:customerId" element={<AddCustomer/>}/>
           
           <Route exact path="/login" element={<Login/>}/>
           <Route exact path="/about" element={<About/>}/>

           <Route exact path="/home" element={<Home/>}/>
           <Route path="*" element={<PageNotFound/>}/>
         </Routes>
      </div>
     </Router>
   );
 }
export default App;