import React, { useState } from 'react';
import Button from "react-bootstrap/Button"
import Menu from '../components/Menu';
import { addCustomer, deleteCustomer, getCustomers, updateCustomer } from '../services/CustomerService';

//functional Comp
export const CustomerAppF =()=> {
  const [items,setItems] = useState(getCustomers());
  const [customer,setCustomer]= useState({name:'',email:'',phone:'',id:0,address:''});
  const [bLabel,setBLabel] = useState('Add');

  const doDelete = (id) => {
    deleteCustomer({id});
    setItems(getCustomers());
  }
  const doEdit = (id) => {
    let temp = items.filter((rec)=>(rec.id == id));
    if(temp.length > 0){
      setBLabel('Update');
      setCustomer({...temp[0]});
    }
  }
  const handleChange = (e) => {
    setCustomer({...customer,[e.target.placeholder.toLowerCase()]: e.target.value });
  }
  const handleSubmit = (e) => {
    //e.preventDefault();
    if (!customer.name.length) {
      return;
    }
    const newItem = {...customer};
    if(customer.id == 0){//add
      addCustomer(newItem);
      setItems(getCustomers());
    }else{ // update
      updateCustomer(newItem);
      setItems(getCustomers());
    }
    doCancel();
  }
  const doCancel = ()=>{
    setCustomer({
      name: '',
      email: '',
      phone: '',
      address: '',
      id: 0
    });
    setBLabel('Add');
  }
    return (
      <div>
        <Menu/>
        <h3>CustomerApp</h3>
        <form>
          <input placeholder='Name'
            onChange={handleChange}
            value={customer.name}
          /><br/><br/>
         <input placeholder='Email'
            onChange={handleChange}
            value={customer.email}
          /><br/><br/>
            <input placeholder='Phone'
            onChange={handleChange}
            value={customer.phone}
          /><br/><br/>
            <input placeholder='Address'
            onChange={handleChange}
            value={customer.address}
          /><br/><br/>
          <Button onClick={handleSubmit}>{bLabel}</Button>
          &nbsp;&nbsp;
          <input type={'button'} value="Cancel" onClick={doCancel} />
        </form><br/><br/>
        <CustomerList items={items}  doDelete={doDelete} doEdit={doEdit}/>
      </div>
    );
  };

function CustomerList ({items,doDelete,doEdit}){
    return (
        <table className="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Copy</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
            {items.map(item => (
            <tr key={item.id}>
                <td>{item.id}</td>
                <td id={item.id}>{item.name}</td>
                <td>{item.email}</td>
                <td>{item.phone}</td>
                <td>{item.address}</td>
                <td><button onClick={()=>doEdit(item.id)} >Copy</button></td>
                <td><button onClick={()=>doEdit(item.id)} >Edit</button></td>
                <td><button onClick={()=>doDelete(item.id)}>Delete</button></td>
                </tr>
          ))}
            </tbody>
        </table>
      );
}

const getNextId = (customers) =>{
  if(customers.length < 1){
     return 1; 
  }
  let numberArry = customers.map((item)=>{return item.id});
  let max = Math.max(...numberArry);// (5,6,6) // spread operator
  return max + 1; 
}
