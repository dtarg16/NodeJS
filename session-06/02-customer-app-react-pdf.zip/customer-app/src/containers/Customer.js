import React, { useState,useEffect } from 'react';
import Button from "react-bootstrap/Button"
import Menu from '../components/Menu';
import { useNavigate } from "react-router-dom";
import { deleteCustomer, getCustomers } from '../services/CustomerAPI';

export default function CustomersApp() {
  const navigate = useNavigate();
  const [items,setItems] = useState([]);
  const [customer,setCustomer]= useState({name:'',email:'',phone:'',id:0,address:''});
  const [bLabel,setBLabel] = useState('Add');

  const loadCustomers = async ()=>{
    setItems(await getCustomers());
  }
  useEffect(()=>{
    loadCustomers();
  },[]);

  const doDelete = async (id) => {
    await deleteCustomer({id});
    setItems(await getCustomers());
  }
  const doEdit = (id) => {
    navigate('/customers/edit/'+id);
  }
    return (
      <div>
        <Menu/>
        <h3>Customers</h3>
        <Button onClick={()=>{navigate('/customer/add')}}>Add</Button>
        <CustomerList items={items}  doDelete={doDelete} doEdit={doEdit}/>
      </div>
    );
  };

function CustomerList ({items,doDelete,doEdit}){
    return (
        <table className="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Copy</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
            {items.map(item => (
            <tr key={item.id}>
                <td>{item.id}</td>
                <td id={item.id}>{item.name}</td>
                <td>{item.email}</td>
                <td>{item.phone}</td>
                <td>{item.address}</td>
                <td><button onClick={()=>doEdit(item.id)} >Copy</button></td>
                <td><button onClick={()=>doEdit(item.id)} >Edit</button></td>
                <td><button onClick={()=>doDelete(item.id)}>Delete</button></td>
                </tr>
          ))}
            </tbody>
        </table>
      );
}