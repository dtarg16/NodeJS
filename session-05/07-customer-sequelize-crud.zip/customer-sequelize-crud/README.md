# express-sequelize-demo

Demo project of NodeJs-Express with MySQL Sequelize.

Steps to follow :-

1. Install node_modules > npm install
2. Open Mysql and create new database.
3. Configure env.js and update your database name, username & password.
4. run nodemon

Thanks
