var express = require('express');
var router = express.Router();
var customerService = require('../service/customerData');
var customerMysql = require('../service/customerMysql');

router.get('/', function(req, res, next) {
  res.redirect("/login");
  //res.render('index', { title: 'Express', name:'Brillio' });
});

router.get('/home', function(req, res, next) {
  res.render('index', { title: 'Home', name:'Brillio' });
});

router.get('/customer', async (req, res, next) => {
  let data = await customerMysql.getCustomers();
  res.render('customer', { title: 'Customers', data});
});

router.get('/customer/add', function(req, res, next) {
  res.render('add-customer', { title: 'Add Customer'});
});

router.get('/customer/edit/:id', async (req, res, next) =>{
  let customer = await customerMysql.getCustomerById(req.params.id);
  res.render('edit-customer', { title: 'Update Customer', customer});
});

router.get('/about', function(req, res, next) {
  res.render('index', { title: 'About', name:'Brillio' });
});

/* GET home page. */
router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Login', name:'Brillio' });
});

module.exports = router;

// check routes/index.js 
// check routes/index.ejs 