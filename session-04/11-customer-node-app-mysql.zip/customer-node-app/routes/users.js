var express = require('express');
var router = express.Router();

// /users
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

// /users/login
router.get('/login', function(req, res, next) {
  res.send('login');
});

 // /users/login
router.post('/login', function(req, res, next) {
  console.log('req.body.username::'+req.body.username);
  console.log('req.body.password::'+req.body.password);
  if(req.body.username == req.body.password && 
    typeof (req.body.username) == 'string'){
    res.send({result:'ok',msg:'login success'});
  }else{
    res.send({result:'fail',msg:'login fail'});
  }
});

module.exports = router;
