var express = require('express');
var router = express.Router();
const {getCustomers,getCustomerById} = require('../services/customerMySQL');

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Customer App' });
});

router.get('/home', function(req, res, next) {
  res.render('index', { title: 'Home' });
});

router.get('/customer', async function(req, res, next) {
  res.render('customer', { title: 'Customer', data:await getCustomers() });
});

router.get('/customer/add', function(req, res, next) {
  const customer = {};
  method="POST";
  res.render('add-customer', { title: 'Add Customer', buttonName:'Add',customer,method});
});

router.get('/customer/edit/:id', async function(req, res, next) {
  const customer = await getCustomerById(req.params.id);
  method="PUT";
  res.render('add-customer', { title: 'Update Customer', buttonName:'Update',customer,method });
});

router.get('/about', async function(req, res, next) {
    res.render('about', { title: 'About', customers: await getCustomers() });
});

router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Login' });
});

module.exports = router;
