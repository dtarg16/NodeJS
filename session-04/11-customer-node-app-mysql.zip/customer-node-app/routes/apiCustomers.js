var express = require('express');
var app = express.Router();
const {getCustomers,getCustomerById, addCustomer, updateCustomer, deleteCustomer} = require('../services/customerMySQL');

  app.get('/', async function (req, res) {
    res.send(await getCustomers());
  })
  
  app.get('/:id', async function (req, res) {
    console.log('id '+req.params.id);
      res.send(await getCustomerById(req.params.id))
  })
  
  app.post('/', async function (req, res) {
    await addCustomer(req.body);
    res.send({result:'ok', msg:'record added successfully'});
  })
  
  app.put('/', async function (req, res) {
    const rec = req.body;
    console.log("rec ",rec);
    await updateCustomer(rec);
    res.send({result:'ok', msg:'record updated successfully'});
  })
  
  app.delete('/', async (req, res) => {
    await deleteCustomer({id:req.body.id});
    res.send({result:'ok',msg:'record deleted successfully'});
  })

module.exports = app;
